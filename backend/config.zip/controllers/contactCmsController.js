const ContactConfig = require("../models/ContactConfig");

// Default initial config generator if empty
const getDefaultConfig = (tenantId) => ({
  tenant: tenantId,
  banner: {
    tagline: "24/7 Dedicated Support",
    title: "Humse Baat Karein, Hum Hamesha Aapke Sath Hain.",
    subtitle: "Product warranty, order tracking, bulk enquiry ya kisi bhi query ke liye hume reach karein."
  },
  cards: [
    {
      title: "Call Us Directly",
      desc: "Mon - Sat: 9:00 AM - 8:00 PM",
      contact: "+91 98765 43210",
      action: "tel:+919876543210",
      btnText: "Call Now",
      gradient: "from-blue-500 to-cyan-500",
      iconType: "phone"
    },
    {
      title: "WhatsApp Chat",
      desc: "Instant priority executive chat",
      contact: "+91 98765 43210",
      action: "https://wa.me/919876543210",
      btnText: "Start Chat",
      gradient: "from-emerald-500 to-teal-500",
      iconType: "whatsapp"
    },
    {
      title: "Official Email",
      desc: "Ticket response in 2-4 hours",
      contact: "support@khastore.com",
      action: "mailto:support@khastore.com",
      btnText: "Send Mail",
      gradient: "from-pink-500 to-rose-500",
      iconType: "mail"
    },
    {
      title: "Main Office & Hub",
      desc: "Hazratganj, Lucknow, UP",
      contact: "Pin: 226001, India",
      action: "https://maps.google.com",
      btnText: "Get Direction",
      gradient: "from-violet-500 to-indigo-500",
      iconType: "map"
    }
  ],
  map: {
    title: "Experience Center Location",
    embedUrl:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d113911.23388796856!2d80.85966601662998!3d26.848622994073356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399bfd991f32b16b%3A0x93ccba8909978be7!2sLucknow%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin",
    visitingHours: "Visiting Hours: 10:00 AM - 7:00 PM (Monday to Saturday)"
  },
  faqs: [
    {
      question: "Order dispatch hone me kitna time lagta hai?",
      answer: "Hum sabhi orders ko 24 ghante ke andar central warehouse se dispatch karte hain. Delivery 2-3 din me ho jati hai."
    },
    {
      question: "Product pasand na aane par return kaise initiate karein?",
      answer: "Aap delivery ke 7 dino ke andar support WhatsApp par message karke hassle-free pickup schedule kar sakte hain."
    },
    {
      question: "Cash on delivery (COD) available hai?",
      answer: "Ji haan, ₹5,000 se upar ke sabhi eligible PIN codes par COD available hai."
    }
  ]
});

// 1. GET PUBLIC CONFIG (With fallback auto-seed)
exports.getContactConfig = async (req, res) => {
  try {
    const tenantId = req.tenant?._id;
    let query = tenantId ? { tenant: tenantId } : {};

    let config = await ContactConfig.findOne(query);
    if (!config) {
      config = await ContactConfig.create(getDefaultConfig(tenantId));
    }

    return res.status(200).json({ success: true, data: config });
  } catch (error) {
    console.error("getContactConfig Error:", error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// 2. UPDATE GENERAL SECTIONS (Banner & Map)
exports.updateGeneralConfig = async (req, res) => {
  try {
    const tenantId = req.tenant?._id;
    let query = tenantId ? { tenant: tenantId } : {};

    const { banner, map } = req.body;
    let updateFields = {};
    if (banner) updateFields.banner = banner;
    if (map) updateFields.map = map;

    const updated = await ContactConfig.findOneAndUpdate(
      query,
      { $set: updateFields },
      { new: true, upsert: true }
    );

    return res.status(200).json({
      success: true,
      message: "Banner and Map configurations updated successfully!",
      data: updated
    });
  } catch (error) {
    console.error("updateGeneralConfig Error:", error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// 3. CONTACT CARDS CRUD
exports.addCard = async (req, res) => {
  try {
    const tenantId = req.tenant?._id;
    const config = await ContactConfig.findOne(tenantId ? { tenant: tenantId } : {});
    if (!config) return res.status(404).json({ success: false, message: "Config not found" });

    config.cards.push(req.body);
    await config.save();

    return res.status(201).json({ success: true, message: "Contact card added!", data: config.cards });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.updateCard = async (req, res) => {
  try {
    const tenantId = req.tenant?._id;
    const config = await ContactConfig.findOne(tenantId ? { tenant: tenantId } : {});
    if (!config) return res.status(404).json({ success: false, message: "Config not found" });

    const card = config.cards.id(req.params.cardId);
    if (!card) return res.status(404).json({ success: false, message: "Card not found" });

    Object.assign(card, req.body);
    await config.save();

    return res.status(200).json({ success: true, message: "Card updated!", data: config.cards });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.deleteCard = async (req, res) => {
  try {
    const tenantId = req.tenant?._id;
    const config = await ContactConfig.findOne(tenantId ? { tenant: tenantId } : {});
    if (!config) return res.status(404).json({ success: false, message: "Config not found" });

    config.cards.pull({ _id: req.params.cardId });
    await config.save();

    return res.status(200).json({ success: true, message: "Card deleted!", data: config.cards });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// 4. FAQS CRUD
exports.addFaq = async (req, res) => {
  try {
    const tenantId = req.tenant?._id;
    const config = await ContactConfig.findOne(tenantId ? { tenant: tenantId } : {});
    if (!config) return res.status(404).json({ success: false, message: "Config not found" });

    config.faqs.push(req.body);
    await config.save();

    return res.status(201).json({ success: true, message: "FAQ added!", data: config.faqs });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.updateFaq = async (req, res) => {
  try {
    const tenantId = req.tenant?._id;
    const config = await ContactConfig.findOne(tenantId ? { tenant: tenantId } : {});
    if (!config) return res.status(404).json({ success: false, message: "Config not found" });

    const faq = config.faqs.id(req.params.faqId);
    if (!faq) return res.status(404).json({ success: false, message: "FAQ not found" });

    Object.assign(faq, req.body);
    await config.save();

    return res.status(200).json({ success: true, message: "FAQ updated!", data: config.faqs });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.deleteFaq = async (req, res) => {
  try {
    const tenantId = req.tenant?._id;
    const config = await ContactConfig.findOne(tenantId ? { tenant: tenantId } : {});
    if (!config) return res.status(404).json({ success: false, message: "Config not found" });

    config.faqs.pull({ _id: req.params.faqId });
    await config.save();

    return res.status(200).json({ success: true, message: "FAQ deleted!", data: config.faqs });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};