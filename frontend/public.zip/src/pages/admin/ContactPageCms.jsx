import React, { useState, useEffect } from "react";
import API from "../../api/axios";
import {
  Layers,
  Sparkles,
  Phone,
  MessageCircle,
  Mail,
  MapPin,
  Clock,
  HelpCircle,
  Plus,
  Edit,
  Trash2,
  X,
  Save,
  RefreshCw,
  ExternalLink
} from "lucide-react";

export default function ContactPageCms() {
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(false);
  const [savingGeneral, setSavingGeneral] = useState(false);

  // General Form (Banner + Map)
  const [banner, setBanner] = useState({ tagline: "", title: "", subtitle: "" });
  const [map, setMap] = useState({ title: "", embedUrl: "", visitingHours: "" });

  // Modal State for Contact Card
  const [cardModalOpen, setCardModalOpen] = useState(false);
  const [editingCard, setEditingCard] = useState(null);
  const [cardForm, setCardForm] = useState({
    title: "",
    desc: "",
    contact: "",
    action: "",
    btnText: "Call Now",
    gradient: "from-blue-500 to-cyan-500",
    iconType: "phone"
  });

  // Modal State for FAQ
  const [faqModalOpen, setFaqModalOpen] = useState(false);
  const [editingFaq, setEditingFaq] = useState(null);
  const [faqForm, setFaqForm] = useState({ question: "", answer: "" });

  // Load Config
  const fetchConfig = async () => {
    setLoading(true);
    try {
      const res = await API.get("/contact/config");
      if (res.data?.success && res.data.data) {
        const d = res.data.data;
        setConfig(d);
        setBanner(d.banner || { tagline: "", title: "", subtitle: "" });
        setMap(d.map || { title: "", embedUrl: "", visitingHours: "" });
      }
    } catch (err) {
      console.error("Fetch CMS config error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchConfig();
  }, []);

  // Save General Banner & Map
  const handleSaveGeneral = async (e) => {
    e.preventDefault();
    setSavingGeneral(true);
    try {
      await API.put("/contact/config/general", { banner, map });
      alert("✅ Banner aur Map details save ho gayi!");
      fetchConfig();
    } catch (err) {
      alert(`❌ Error: ${err.response?.data?.message || err.message}`);
    } finally {
      setSavingGeneral(false);
    }
  };

  // Card Handlers
  const handleOpenAddCard = () => {
    setEditingCard(null);
    setCardForm({
      title: "",
      desc: "",
      contact: "",
      action: "",
      btnText: "Contact Now",
      gradient: "from-blue-500 to-cyan-500",
      iconType: "phone"
    });
    setCardModalOpen(true);
  };

  const handleOpenEditCard = (card) => {
    setEditingCard(card);
    setCardForm({
      title: card.title || "",
      desc: card.desc || "",
      contact: card.contact || "",
      action: card.action || "",
      btnText: card.btnText || "Contact Now",
      gradient: card.gradient || "from-blue-500 to-cyan-500",
      iconType: card.iconType || "phone"
    });
    setCardModalOpen(true);
  };

  const handleSaveCard = async (e) => {
    e.preventDefault();
    try {
      if (editingCard) {
        await API.put(`/contact/config/cards/${editingCard._id}`, cardForm);
        alert("✅ Contact card update ho gaya!");
      } else {
        await API.post("/contact/config/cards", cardForm);
        alert("✅ Naya Contact card jud gaya!");
      }
      setCardModalOpen(false);
      fetchConfig();
    } catch (err) {
      alert(`❌ Error: ${err.response?.data?.message || err.message}`);
    }
  };

  const handleDeleteCard = async (id) => {
    if (window.confirm("Kya aap sach me is Contact Card ko delete karna chahte hain?")) {
      try {
        await API.delete(`/contact/config/cards/${id}`);
        fetchConfig();
      } catch (err) {
        alert(`❌ Delete error: ${err.response?.data?.message || err.message}`);
      }
    }
  };

  // FAQ Handlers
  const handleOpenAddFaq = () => {
    setEditingFaq(null);
    setFaqForm({ question: "", answer: "" });
    setFaqModalOpen(true);
  };

  const handleOpenEditFaq = (faq) => {
    setEditingFaq(faq);
    setFaqForm({ question: faq.question || "", answer: faq.answer || "" });
    setFaqModalOpen(true);
  };

  const handleSaveFaq = async (e) => {
    e.preventDefault();
    try {
      if (editingFaq) {
        await API.put(`/contact/config/faqs/${editingFaq._id}`, faqForm);
        alert("✅ FAQ update ho gaya!");
      } else {
        await API.post("/contact/config/faqs", faqForm);
        alert("✅ Naya FAQ jud gaya!");
      }
      setFaqModalOpen(false);
      fetchConfig();
    } catch (err) {
      alert(`❌ Error: ${err.response?.data?.message || err.message}`);
    }
  };

  const handleDeleteFaq = async (id) => {
    if (window.confirm("Kya aap sach me is FAQ ko delete karna chahte hain?")) {
      try {
        await API.delete(`/contact/config/faqs/${id}`);
        fetchConfig();
      } catch (err) {
        alert(`❌ Delete error: ${err.response?.data?.message || err.message}`);
      }
    }
  };

  return (
    <div className="p-6 sm:p-8 space-y-8 max-w-6xl mx-auto">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Contact Page CMS & Visual Editor
          </h1>
          <p className="text-xs text-slate-400 font-bold mt-0.5">
            Manage public contact banners, priority channel cards, Google Maps location & FAQ accordions
          </p>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="/contact"
            target="_blank"
            rel="noreferrer"
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center gap-1.5 transition"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>View Live Page</span>
          </a>
          <button
            onClick={fetchConfig}
            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition cursor-pointer"
            title="Refresh CMS"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {/* SECTION 1: Banner & Google Map General Form */}
      <form onSubmit={handleSaveGeneral} className="bg-white rounded-3xl border border-slate-100 p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-pink-50 text-pink-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <h3 className="font-black text-sm text-slate-900">Hero Banner & Office Map Configuration</h3>
          </div>
          <button
            type="submit"
            disabled={savingGeneral}
            className="px-5 py-2.5 bg-gradient-to-r from-violet-600 to-pink-600 hover:opacity-95 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 transition cursor-pointer disabled:opacity-50"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{savingGeneral ? "Saving..." : "Save Banner & Map"}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs font-bold text-slate-700">
          <div>
            <label className="block mb-1">Banner Tagline Badge</label>
            <input
              type="text"
              value={banner.tagline}
              onChange={(e) => setBanner({ ...banner, tagline: e.target.value })}
              placeholder="e.g. 24/7 Dedicated Support"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 outline-none focus:bg-white focus:border-pink-500 font-semibold"
            />
          </div>

          <div>
            <label className="block mb-1">Banner Headline Title</label>
            <input
              type="text"
              value={banner.title}
              onChange={(e) => setBanner({ ...banner, title: e.target.value })}
              placeholder="Main Headline"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 outline-none focus:bg-white focus:border-pink-500 font-semibold"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block mb-1">Banner Subtitle Description</label>
            <textarea
              rows={2}
              value={banner.subtitle}
              onChange={(e) => setBanner({ ...banner, subtitle: e.target.value })}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 outline-none focus:bg-white focus:border-pink-500 font-semibold resize-none"
            />
          </div>

          <div className="md:col-span-2 pt-3 border-t border-slate-100">
            <label className="block mb-1">Google Maps Iframe Embed URL (src)</label>
            <input
              type="text"
              value={map.embedUrl}
              onChange={(e) => setMap({ ...map, embedUrl: e.target.value })}
              placeholder="https://www.google.com/maps/embed?pb=..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 outline-none focus:bg-white focus:border-pink-500 font-mono text-[11px]"
            />
          </div>

          <div>
            <label className="block mb-1">Map Box Heading</label>
            <input
              type="text"
              value={map.title}
              onChange={(e) => setMap({ ...map, title: e.target.value })}
              placeholder="e.g. Experience Center Location"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 outline-none focus:bg-white focus:border-pink-500 font-semibold"
            />
          </div>

          <div>
            <label className="block mb-1">Visiting Timings</label>
            <input
              type="text"
              value={map.visitingHours}
              onChange={(e) => setMap({ ...map, visitingHours: e.target.value })}
              placeholder="e.g. Visiting Hours: 10:00 AM - 7:00 PM"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 outline-none focus:bg-white focus:border-pink-500 font-semibold"
            />
          </div>
        </div>
      </form>

      {/* SECTION 2: Contact Channel Cards CRUD */}
      <div className="bg-white rounded-3xl border border-slate-100 p-6 sm:p-8 shadow-sm space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-sm text-slate-900">Contact Channels Cards ({(config?.cards || []).length})</h3>
              <p className="text-[11px] text-slate-400">Phone, WhatsApp, Email, and Location Cards on public page</p>
            </div>
          </div>

          <button
            onClick={handleOpenAddCard}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-md transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Card</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {(config?.cards || []).map((card) => (
            <div
              key={card._id}
              className="p-5 rounded-2xl border border-slate-100 bg-slate-50/70 hover:bg-white hover:shadow-md transition flex flex-col justify-between space-y-3"
            >
              <div>
                <span className="px-2 py-0.5 rounded text-[9px] font-black uppercase bg-white border border-slate-200 text-slate-600">
                  {card.iconType}
                </span>
                <h4 className="font-extrabold text-slate-900 text-sm mt-2">{card.title}</h4>
                <p className="text-[11px] text-slate-400 mt-0.5">{card.desc}</p>
                <p className="text-xs font-black text-slate-800 mt-2 font-mono">{card.contact}</p>
              </div>

              <div className="flex items-center justify-end gap-1.5 pt-2 border-t border-slate-200/60">
                <button
                  onClick={() => handleOpenEditCard(card)}
                  className="p-1.5 bg-white hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 rounded-lg border border-slate-200 transition cursor-pointer"
                  title="Edit Card"
                >
                  <Edit className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleDeleteCard(card._id)}
                  className="p-1.5 bg-white hover:bg-rose-50 text-slate-600 hover:text-rose-600 rounded-lg border border-slate-200 transition cursor-pointer"
                  title="Delete Card"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 3: FAQ Accordion CRUD */}
      <div className="bg-white rounded-3xl border border-slate-100 p-6 sm:p-8 shadow-sm space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-sm text-slate-900">Frequently Asked Questions ({(config?.faqs || []).length})</h3>
              <p className="text-[11px] text-slate-400">Questions answered on the Contact Us public page</p>
            </div>
          </div>

          <button
            onClick={handleOpenAddFaq}
            className="px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-md transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add FAQ</span>
          </button>
        </div>

        <div className="space-y-3">
          {(config?.faqs || []).map((faq) => (
            <div
              key={faq._id}
              className="p-4 rounded-2xl border border-slate-100 bg-slate-50/60 flex items-start justify-between gap-4"
            >
              <div className="space-y-1 text-xs">
                <p className="font-extrabold text-slate-900">{faq.question}</p>
                <p className="text-slate-500 leading-relaxed">{faq.answer}</p>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => handleOpenEditFaq(faq)}
                  className="p-1.5 bg-white hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 rounded-lg border border-slate-200 transition cursor-pointer"
                  title="Edit FAQ"
                >
                  <Edit className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleDeleteFaq(faq._id)}
                  className="p-1.5 bg-white hover:bg-rose-50 text-slate-600 hover:text-rose-600 rounded-lg border border-slate-200 transition cursor-pointer"
                  title="Delete FAQ"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* MODAL 1: ADD / EDIT CARD */}
      {cardModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="flex justify-between items-center pb-2 border-b">
              <h3 className="font-black text-sm text-slate-900">
                {editingCard ? "Edit Contact Card" : "Add New Contact Card"}
              </h3>
              <button onClick={() => setCardModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleSaveCard} className="space-y-3 text-xs font-bold text-slate-700">
              <div>
                <label className="block mb-1">Title *</label>
                <input
                  type="text"
                  required
                  value={cardForm.title}
                  onChange={(e) => setCardForm({ ...cardForm, title: e.target.value })}
                  placeholder="e.g. Call Us Directly"
                  className="w-full border rounded-xl p-2.5 outline-none"
                />
              </div>

              <div>
                <label className="block mb-1">Sub-description</label>
                <input
                  type="text"
                  value={cardForm.desc}
                  onChange={(e) => setCardForm({ ...cardForm, desc: e.target.value })}
                  placeholder="e.g. Mon - Sat: 9:00 AM - 8:00 PM"
                  className="w-full border rounded-xl p-2.5 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block mb-1">Icon Type</label>
                  <select
                    value={cardForm.iconType}
                    onChange={(e) => setCardForm({ ...cardForm, iconType: e.target.value })}
                    className="w-full border rounded-xl p-2.5 outline-none bg-white cursor-pointer"
                  >
                    <option value="phone">Phone Call</option>
                    <option value="whatsapp">WhatsApp</option>
                    <option value="mail">Email</option>
                    <option value="map">Map Location</option>
                  </select>
                </div>
                <div>
                  <label className="block mb-1">Button Text</label>
                  <input
                    type="text"
                    value={cardForm.btnText}
                    onChange={(e) => setCardForm({ ...cardForm, btnText: e.target.value })}
                    placeholder="e.g. Call Now"
                    className="w-full border rounded-xl p-2.5 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block mb-1">Contact Display Text *</label>
                <input
                  type="text"
                  required
                  value={cardForm.contact}
                  onChange={(e) => setCardForm({ ...cardForm, contact: e.target.value })}
                  placeholder="e.g. +91 98765 43210 ya support@store.com"
                  className="w-full border rounded-xl p-2.5 outline-none"
                />
              </div>

              <div>
                <label className="block mb-1">Action Link (Href) *</label>
                <input
                  type="text"
                  required
                  value={cardForm.action}
                  onChange={(e) => setCardForm({ ...cardForm, action: e.target.value })}
                  placeholder="tel:+919876543210 ya https://wa.me/919876543210"
                  className="w-full border rounded-xl p-2.5 outline-none font-mono text-[11px]"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition cursor-pointer"
                >
                  Save Card
                </button>
                <button
                  type="button"
                  onClick={() => setCardModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 text-slate-700 font-bold rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: ADD / EDIT FAQ */}
      {faqModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="flex justify-between items-center pb-2 border-b">
              <h3 className="font-black text-sm text-slate-900">
                {editingFaq ? "Edit FAQ" : "Add New FAQ"}
              </h3>
              <button onClick={() => setFaqModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleSaveFaq} className="space-y-3 text-xs font-bold text-slate-700">
              <div>
                <label className="block mb-1">Question *</label>
                <input
                  type="text"
                  required
                  value={faqForm.question}
                  onChange={(e) => setFaqForm({ ...faqForm, question: e.target.value })}
                  placeholder="e.g. Return kaise initiate karein?"
                  className="w-full border rounded-xl p-2.5 outline-none"
                />
              </div>

              <div>
                <label className="block mb-1">Answer *</label>
                <textarea
                  rows={4}
                  required
                  value={faqForm.answer}
                  onChange={(e) => setFaqForm({ ...faqForm, answer: e.target.value })}
                  placeholder="Detailed answer text..."
                  className="w-full border rounded-xl p-2.5 outline-none resize-none font-semibold"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl transition cursor-pointer"
                >
                  Save FAQ
                </button>
                <button
                  type="button"
                  onClick={() => setFaqModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 text-slate-700 font-bold rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}