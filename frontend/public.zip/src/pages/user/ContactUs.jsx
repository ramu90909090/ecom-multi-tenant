import React, { useState, useEffect } from "react";
import {
  Mail,
  Phone,
  MapPin,
  Send,
  MessageCircle,
  Clock,
  CheckCircle2,
  Sparkles,
  HelpCircle,
  ChevronDown
} from "lucide-react";
import API from "../../api/axios";

export default function ContactUs() {
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeFaq, setActiveFaq] = useState(null);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "Order Status",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Fetch Dynamic Page Content
  useEffect(() => {
    const fetchConfig = async () => {
      try {
        setLoading(true);
        const res = await API.get("/contact/config");
        if (res.data?.success) {
          setConfig(res.data.data);
        }
      } catch (err) {
        console.error("Error fetching contact config:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchConfig();
  }, []);

  // Submit Inquiry Ticket
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await API.post("/contact/query", formData);
      if (res.data?.success) {
        setIsSubmitted(true);
        setFormData({ name: "", email: "", phone: "", subject: "Order Status", message: "" });
        setTimeout(() => setIsSubmitted(false), 5000);
      }
    } catch (err) {
      alert(`❌ Error submitting message: ${err.response?.data?.message || err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getIcon = (type) => {
    switch (type) {
      case "phone":
        return Phone;
      case "whatsapp":
        return MessageCircle;
      case "mail":
        return Mail;
      case "map":
        return MapPin;
      default:
        return Phone;
    }
  };

  if (loading) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-pink-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const banner = config?.banner || {};
  const cards = config?.cards || [];
  const mapData = config?.map || {};
  const faqs = config?.faqs || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      
      {/* 1. Header Banner */}
      <section className="relative overflow-hidden bg-gradient-to-r from-violet-600 via-pink-600 to-amber-500 rounded-3xl p-8 sm:p-12 text-white shadow-xl">
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>{banner.tagline || "24/7 Dedicated Support"}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight">
            {banner.title || "Humse Baat Karein, Hum Hamesha Aapke Sath Hain."}
          </h1>
          <p className="text-pink-100 text-xs sm:text-sm">
            {banner.subtitle || "Product warranty, order tracking, bulk enquiry ya kisi bhi query ke liye hume reach karein."}
          </p>
        </div>
        <div className="absolute -right-8 -bottom-8 w-60 h-60 bg-white/10 rounded-full blur-3xl pointer-events-none" />
      </section>

      {/* 2. Interactive Contact Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {cards.map((c, i) => {
          const IconComp = getIcon(c.iconType);
          return (
            <div
              key={c._id || i}
              className="group bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between"
            >
              <div>
                <div
                  className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${
                    c.gradient || "from-pink-500 to-rose-500"
                  } flex items-center justify-center text-white mb-4 shadow-md group-hover:scale-110 transition-transform`}
                >
                  <IconComp className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-gray-900 text-base">{c.title}</h3>
                <p className="text-xs text-gray-500 mt-1">{c.desc}</p>
                <p className="text-sm font-extrabold text-gray-800 mt-2">{c.contact}</p>
              </div>

              <a
                href={c.action}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-5 w-full py-2.5 rounded-xl border border-gray-200 text-xs font-bold text-gray-700 hover:bg-gray-900 hover:text-white hover:border-gray-900 text-center transition duration-200"
              >
                {c.btnText || "Contact"}
              </a>
            </div>
          );
        })}
      </section>

      {/* 3. Inquiry Form + Dynamic Google Map */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Support Inquiry Form */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-gray-100 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-gray-100 pb-4">
            <div>
              <span className="text-xs font-bold text-pink-600 uppercase tracking-widest bg-pink-50 px-3 py-1 rounded-full">
                Quick Ticket
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-gray-900 mt-2">
                Send Us a Direct Message
              </h2>
            </div>
            <div className="flex items-center space-x-1.5 text-xs text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Agents Online</span>
            </div>
          </div>

          {isSubmitted ? (
            <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 text-center space-y-2 animate-in fade-in">
              <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
              <h4 className="font-bold text-emerald-900 text-base">Message Sent Successfully!</h4>
              <p className="text-xs text-emerald-700">Aapki request log kar li gayi hai. Humara support executive aapse jald hi sampark karega.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Full Name *</label>
                  <input
                    required
                    type="text"
                    placeholder="e.g. Rahul Sharma"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 focus:bg-white focus:border-pink-500 focus:ring-4 focus:ring-pink-500/10 rounded-xl px-4 py-2.5 text-xs font-medium outline-none transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Phone Number *</label>
                  <input
                    required
                    type="tel"
                    placeholder="+91 98765 00000"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 focus:bg-white focus:border-pink-500 focus:ring-4 focus:ring-pink-500/10 rounded-xl px-4 py-2.5 text-xs font-medium outline-none transition"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Email Address *</label>
                  <input
                    required
                    type="email"
                    placeholder="rahul@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 focus:bg-white focus:border-pink-500 focus:ring-4 focus:ring-pink-500/10 rounded-xl px-4 py-2.5 text-xs font-medium outline-none transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Inquiry Type</label>
                  <select
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 focus:bg-white focus:border-pink-500 focus:ring-4 focus:ring-pink-500/10 rounded-xl px-4 py-2.5 text-xs font-medium outline-none transition cursor-pointer"
                  >
                    <option value="Order Status">Order Status & Tracking</option>
                    <option value="Return / Refund">Return & Refund Request</option>
                    <option value="Product Query">Product Information</option>
                    <option value="Partnership">Business Partnership</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Your Detailed Message *</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Order ID ya issue explain karein..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 focus:bg-white focus:border-pink-500 focus:ring-4 focus:ring-pink-500/10 rounded-xl px-4 py-2.5 text-xs font-medium outline-none transition resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 bg-gradient-to-r from-violet-600 via-pink-600 to-amber-500 hover:opacity-95 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-pink-500/25 active:scale-95 transition flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span>{isSubmitting ? "Submitting Ticket..." : "Submit Ticket"}</span>
              </button>
            </form>
          )}
        </div>

        {/* Dynamic Embedded Map & FAQs */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm space-y-4">
            <div className="flex items-center space-x-2">
              <MapPin className="w-5 h-5 text-pink-600" />
              <h3 className="font-bold text-gray-900 text-sm">{mapData.title || "Experience Center Location"}</h3>
            </div>
            
            <div className="h-64 sm:h-72 w-full rounded-2xl overflow-hidden border border-gray-200 shadow-inner">
              <iframe
                title="Office Location Map"
                src={
                  mapData.embedUrl ||
                  "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d113911.23388796856!2d80.85966601662998!3d26.848622994073356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399bfd991f32b16b%3A0x93ccba8909978be7!2sLucknow%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
                }
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>

            <div className="flex items-center space-x-2 text-xs text-gray-500 pt-1">
              <Clock className="w-4 h-4 text-violet-600 shrink-0" />
              <span>{mapData.visitingHours || "Visiting Hours: 10:00 AM - 7:00 PM (Monday to Saturday)"}</span>
            </div>
          </div>

          {/* Dynamic FAQs Accordion */}
          {faqs.length > 0 && (
            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-3">
              <div className="flex items-center space-x-2 mb-2">
                <HelpCircle className="w-4 h-4 text-violet-600" />
                <h4 className="font-bold text-gray-900 text-sm">Frequently Asked Questions</h4>
              </div>

              <div className="space-y-2">
                {faqs.map((faq, idx) => (
                  <div key={faq._id || idx} className="border border-gray-100 rounded-xl overflow-hidden">
                    <button
                      onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                      className="w-full p-3 text-left font-semibold text-xs text-gray-800 flex justify-between items-center bg-gray-50/70 hover:bg-gray-100 transition"
                    >
                      <span>{faq.question}</span>
                      <ChevronDown
                        className={`w-3.5 h-3.5 text-gray-400 transition-transform ${
                          activeFaq === idx ? "rotate-180" : ""
                        }`}
                      />
                    </button>
                    {activeFaq === idx && (
                      <div className="p-3 text-xs text-gray-600 bg-white leading-relaxed border-t border-gray-100">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

      </section>

    </div>
  );
}